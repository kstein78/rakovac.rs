# Rakovac Capital & Rakovac Common, v1.1

Fonts made for the village of Rakovac, Fruška Gora: https://rakovac.rs/fonts/

## Contents
- **Rakovac Capital/**
  - `RakovacCapitalColor-Regular.otf`: the colour version. Install it on Windows or macOS.
  - `RakovacCapital-Regular.otf`: the one-colour version, for vinyl cutting, stamps, embroidery, and apps that don't support colour fonts.
  - `graphics/colour/` and `graphics/one-colour/`: every letter as an SVG file for print shops, Canva, Illustrator and Inkscape.
  - `graphics/RakovacCapital-R-logo-*.png`: the logo R, 2240 px, transparent background.
  - `LICENSE-RakovacCapital.txt`: the licence.
- **Rakovac Common/**: `RakovacCommon-Variable.ttf` and `RakovacCommon-Italic-Variable.ttf`. Each file holds every weight from Light to Black. Licence: `OFL.txt`.
- **webfonts/**: `.woff2` files and `rakovac-fonts.css`, for any website.
- `Rakovac-Fonts-Guide-EN.pdf`, `Rakovac-Fontovi-Uputstvo-SR.pdf`: how to use the fonts and the logo.

## Letters in Rakovac Capital
- **Latin:** A–Z, Č Ć Š Ž Đ, Ä Ö Ü Ë, Á É Í Ó Ú, Ő Ű.
- **Cyrillic:** А Б В Г Д Ђ Е Ё Ж З И Й Ј К Л Љ М Н Њ О П Р С Т Ћ У Ф Х Ц Ч Џ Ш Щ Ъ Ы Ь Э Ю Я, and Є І Ї Ѕ.
- **Lowercase keys** type the same capitals.

Set the Capital at the **same size** as Rakovac Common. The letter in the shield then sits on the text baseline at cap height, and the point of the shield hangs below the line.

## Install
- **Windows:** right-click each `.otf` or `.ttf` file and choose **Install for all users**.
- **macOS:** double-click the file and choose **Install Font**.
- **Colour support:**
  - Word and PowerPoint in Microsoft 365 show the colours.
  - Adobe Illustrator, InDesign and Photoshop show the colours.
  - Canva and Google Docs show only one colour, so place the first letter there as an SVG image.

## Website
Link `webfonts/rakovac-fonts.css`. Write the first letter as `<span class="rk-cap">R</span>akovac`.

## Licence (summary)
- **Free use:** Rakovac Capital is free for personal and commercial use.
- **Credit:** commercial use requires the credit **Font: Rakovac Capital, rakovac.rs**.
- **No credit needed if:** you have written permission from the author, or your business is located in Rakovac or related to it.
- **Selling and sharing:** you may not sell the font itself. Share it only together with the licence file.
- **The full text** is in `LICENSE-RakovacCapital.txt`.

Rakovac Common is Literata (© The Literata Project Authors) under a new name, licensed under the SIL Open Font License 1.1.

© 2026 Konstantin Stein, rakovac.rs. Designed together with Claude (Anthropic).
Contact: konstantin.stein@gmail.com
